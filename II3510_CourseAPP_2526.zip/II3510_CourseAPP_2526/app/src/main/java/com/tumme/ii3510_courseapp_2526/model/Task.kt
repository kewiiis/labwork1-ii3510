package com.tumme.ii3510_courseapp_2526.model

data class Task(
    val id: Int,
    val title: String,
    val description: String = ""
)
