package com.tumme.scrudstudents

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SCRUDStudents : Application()