package com.tumme.scrudstudents.data.local.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

/**
 * Entité Room pour la table students.
 * Définit la structure des données d'un étudiant.
 */
@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey val idStudent: Int,
    val lastName: String,
    val firstName: String,
    val dateOfBirth: Date,
    val gender: Gender
)