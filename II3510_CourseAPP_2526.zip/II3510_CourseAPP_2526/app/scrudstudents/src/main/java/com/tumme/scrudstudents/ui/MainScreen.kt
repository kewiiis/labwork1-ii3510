package com.tumme.scrudstudents.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tumme.scrudstudents.ui.navigation.Routes
import com.tumme.scrudstudents.ui.student.StudentListScreen
import com.tumme.scrudstudents.ui.student.StudentFormScreen
import com.tumme.scrudstudents.ui.student.StudentDetailScreen
import com.tumme.scrudstudents.ui.course.CourseListScreen
import com.tumme.scrudstudents.ui.course.CourseFormScreen
import com.tumme.scrudstudents.ui.course.CourseDetailScreen
import com.tumme.scrudstudents.ui.subscribe.SubscribeListScreen
import com.tumme.scrudstudents.ui.subscribe.SubscribeFormScreen
import com.tumme.scrudstudents.ui.subscribe.SubscribeDetailScreen

/**
 * Écran principal avec BottomNavigation pour naviguer entre les sections.
 * 
 * Cet écran fait partie de la couche UI de l'architecture MVVM.
 * Il fournit une navigation principale entre Students et Courses.
 * 
 * Responsabilités :
 * - Afficher la BottomNavigation Material 3
 * - Gérer la navigation entre les sections principales
 * - Afficher le contenu de la section sélectionnée
 * 
 * Liaisons :
 * - Amont : MainActivity
 * - Aval : StudentListScreen, CourseListScreen, SubscribeListScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val navController = rememberNavController()
    
    /**
     * Scaffold Material 3 avec BottomNavigation.
     * 
     * La structure suit les guidelines Material Design 3 :
     * - BottomNavigation pour la navigation principale
     * - Content area pour les écrans de chaque section
     */
    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                
                // Item Students
                NavigationBarItem(
                    icon = { Text("👥") },
                    label = { Text("Students") },
                    selected = currentDestination?.hierarchy?.any { it.route == Routes.STUDENT_LIST } == true,
                    onClick = {
                        navController.navigate(Routes.STUDENT_LIST) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                
                // Item Courses
                NavigationBarItem(
                    icon = { Text("📚") },
                    label = { Text("Courses") },
                    selected = currentDestination?.hierarchy?.any { it.route == Routes.COURSE_LIST } == true,
                    onClick = {
                        navController.navigate(Routes.COURSE_LIST) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
                
                // Item Subscriptions
                NavigationBarItem(
                    icon = { Text("📝") },
                    label = { Text("Subscriptions") },
                    selected = currentDestination?.hierarchy?.any { it.route == Routes.SUBSCRIBE_LIST } == true,
                    onClick = {
                        navController.navigate(Routes.SUBSCRIBE_LIST) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { padding ->
        /**
         * Navigation host pour les sections principales.
         * 
         * Chaque section a sa propre pile de navigation :
         * - Students : Liste → Formulaire → Détail
         * - Courses : Liste → Formulaire → Détail
         */
        NavHost(
            navController = navController,
            startDestination = Routes.STUDENT_LIST,
            modifier = Modifier.padding(padding)
        ) {
            // Section Students
            composable(Routes.STUDENT_LIST) {
                StudentListScreen(
                    onNavigateToForm = { 
                        navController.navigate(Routes.STUDENT_FORM)
                    },
                    onNavigateToDetail = { id -> 
                        navController.navigate("student_detail/$id")
                    }
                )
            }
            composable(Routes.STUDENT_FORM) {
                StudentFormScreen(
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("student_detail/{studentId}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("studentId")?.toIntOrNull() ?: 0
                StudentDetailScreen(
                    studentId = id,
                    onBack = { navController.popBackStack() }
                )
            }
            
            // Section Courses
            composable(Routes.COURSE_LIST) {
                CourseListScreen(
                    onNavigateToForm = { 
                        navController.navigate(Routes.COURSE_FORM)
                    },
                    onNavigateToDetail = { id -> 
                        navController.navigate("course_detail/$id")
                    }
                )
            }
            composable(Routes.COURSE_FORM) {
                CourseFormScreen(
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("course_detail/{courseId}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("courseId")?.toIntOrNull() ?: 0
                CourseDetailScreen(
                    courseId = id,
                    onBack = { navController.popBackStack() }
                )
            }
            
            // Section Subscriptions
            composable(Routes.SUBSCRIBE_LIST) {
                SubscribeListScreen(
                    onNavigateToForm = { 
                        navController.navigate(Routes.SUBSCRIBE_FORM)
                    },
                    onNavigateToDetail = { studentId, courseId -> 
                        navController.navigate("subscribe_detail/$studentId/$courseId")
                    }
                )
            }
            composable(Routes.SUBSCRIBE_FORM) {
                SubscribeFormScreen(
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("subscribe_detail/{studentId}/{courseId}") { backStackEntry ->
                val studentId = backStackEntry.arguments?.getString("studentId")?.toIntOrNull() ?: 0
                val courseId = backStackEntry.arguments?.getString("courseId")?.toIntOrNull() ?: 0
                SubscribeDetailScreen(
                    studentId = studentId,
                    courseId = courseId,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
