# Android SCRUD Application Documentation

## Architecture Used

This Android application implements a clean MVVM architecture with four distinct layers. The **Data Layer** consists of Room entities (`StudentEntity`, `CourseEntity`, `SubscribeEntity`) with corresponding DAOs that expose reactive `Flow<List<T>>` streams. The **Repository Layer** (`SCRUDRepository`) abstracts data access by delegating to individual DAOs and provides a unified interface for ViewModels. The **Presentation Layer** contains ViewModels that convert DAO flows into `StateFlow` using `stateIn()` and manage business logic through coroutines. The **UI Layer** uses Jetpack Compose with `collectAsState()` to reactively observe ViewModel state changes.

Hilt handles dependency injection through `AppModule` (see `di/AppModule.kt`), providing singletons for the database, DAOs, and repository. ViewModels are injected using `@HiltViewModel` and `@Inject` annotations. Navigation is implemented via `MainScreen.kt` with a bottom navigation bar containing three tabs: Students, Courses, and Subscriptions, each leading to respective list screens with floating action buttons for creation.

## Data Flow

The application follows a reactive data flow pattern. For **read operations**: Room database changes trigger DAO flows, which are collected by the repository and exposed to ViewModels. ViewModels convert these flows to `StateFlow` using `stateIn(viewModelScope, SharingStarted.Lazily, emptyList())`. Compose UI components collect these StateFlows via `collectAsState()`, triggering automatic recomposition when data changes.

For **write operations**: UI events trigger ViewModel functions that launch coroutines using `viewModelScope.launch`. These coroutines call repository methods, which delegate to DAO suspend functions. Database updates automatically propagate back through the reactive chain, causing UI recomposition.

```
Room DB
  ↑   ↓
DAO ↔ Repository
      ↓
  ViewModel (StateFlow)
      ↓ (collectAsState)
    Compose UI
```

**Course validation** is enforced in `ui/course/CourseFormScreen.kt` through UI-level validation: ECTS credits must be positive (`ectsValue > 0`) and course level must belong to the predefined enum `{P1, P2, P3, B1, B2, B3, A1, A2, A3, MS, PhD}` via dropdown selection. **Subscribe relationships** use foreign keys in `data/local/model/SubscribeEntity.kt` linking `studentId` and `courseId` to their respective entities. The list display performs UI-side joins in `ui/subscribe/SubscribeRow.kt` by finding corresponding student and course entities by ID to display names instead of raw IDs.

## Difficulties Encountered

• **Managing recomposition with collectAsState()**: Ensuring UI state consistency while avoiding redundant recompositions. *Solution: Used `remember` for local state and `collectAsState()` only for ViewModel state.*

• **Validating form inputs**: Implementing Course validation for ECTS > 0 and level constraints. *Solution: Added client-side validation in form screens with error state management and user feedback.*

• **Loading dropdown data for Subscribe**: Handling Student/Course selection and empty states in subscription forms. *Solution: Collected both student and course lists in `SubscribeListViewModel` and used `ExposedDropdownMenu` for selection.*

• **Designing DAO queries/JOINs**: Displaying Student and Course names instead of IDs in subscription lists. *Solution: Implemented UI-side joins using `find()` operations on collected entity lists rather than complex SQL JOINs.*

• **Dependency injection boundaries**: Managing Hilt module configuration and ViewModel injection. *Solution: Created centralized `AppModule` with proper `@Provides` methods and used `@HiltViewModel` for ViewModel injection.*

## Cross-references to code

Key implementation files include `data/local/dao/StudentDao.kt` for Room queries, `ui/student/StudentListViewModel.kt` for StateFlow exposure, `ui/course/CourseFormScreen.kt` for validation logic, and `ui/subscribe/SubscribeRow.kt` for UI-side joins. The navigation structure is defined in `ui/MainScreen.kt` with bottom navigation implementation.